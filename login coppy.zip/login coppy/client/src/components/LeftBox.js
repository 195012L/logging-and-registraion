import React, { useState } from "react";
import axios from "axios";

export default function LeftBox() {
  let [good, setgood] = useState(0);
  let [bad, setbad] = useState(0);

  let [fname, setfname] = useState("");
  let [mname, setmname] = useState("");
  let [lname, setlname] = useState("");
  let [review, setreview] = useState("");

  return (
    <div className="firstbox">
      <br />
      <br />
      First Name : <br />
      <br />
      <input
        name="fname"
        type="text"
        value={fname}
        placeholder="Enter your first name here"
        onChange={(e) => {
          setfname(e.target.value);
        }}
      />
      <br />
      <br />
      Last Name : <br />
      <br />
      <input
        name="lname"
        type="text"
        value={lname}
        placeholder="Enter your last name here"
        onChange={(e) => {
          setlname(e.target.value);
        }}
      />
      <br />
      <br />
      Suggestions : <br />
      <br />
      <input
        name="review"
        type="text"
        value={review}
        placeholder="Tell us your thoughts here"
        onChange={(e) => {
          setreview(e.target.value);
        }}
      />
      <br />
      <br />
      <button
        onClick={(e) => {
          if (fname === "" || lname === "" || review === "")
            alert("FILL THE FIELDS");
          else if (
            fname.length > 40 ||
            mname.length > 40 ||
            lname.length > 40 ||
            review.length > 40
          ) {
            alert("ENTER LESS THAN 40 CHARACTERS IN A PARTICULAR FIELD");
          } else {
            // setfeed((list) => {
            //   return [
            //     ...list,
            //     {
            //       firstname: fname,
            //       middlename: mname,
            //       lastname: lname,
            //       post: review,
            //     },
            //   ];
            // });

            axios
              .post("http://localhost:5000/feedback/add", {
                fname: fname,
                lname: lname,
                suggestion: review,
              })
              .then((res) => {
                console.log(res);
                if (res.data == "FeedBack created") {
                  alert("FeedBack added.Thanks!");
                  window.location.reload();
                } else {
                  alert("Try again");
                }
              });

            setfname("");
            setmname("");
            setlname("");
            setreview("");
          }
        }}
      >
        ADD MY SUGGESTION
      </button>
    </div>
  );
}
