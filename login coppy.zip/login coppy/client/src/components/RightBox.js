import React, { useEffect, useState } from "react";
import Feedback from "./Feedback";
import axios from "axios";

const RightBox = () => {
  const [data, setData] = useState([]);
  useEffect(() => {
    axios.get("http://localhost:3000/feedback/get").then((res) => {
      setData(res.data);
    });
  }, "");
  return (
    <>
      <div className="secondbox">
        <>
          <br />
          <div className="feed">
            <h3>Firstname Lastname Suggestions</h3>
          </div>
        </>

        {Array.isArray(data) &&
          data.map((d) => {
            return (
              <>
                <br />
                <div className="feed">
                  <h3>
                    {d.firstName} {d.lastName} {d.sugeestion}
                  </h3>
                </div>
              </>
            );
          })}
      </div>
    </>
  );
};
export default RightBox;
