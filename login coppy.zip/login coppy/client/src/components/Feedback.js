import BuyerSidebar from "./BuyerSideBar";
import Tablechart from "./Tablechart";
import { Formik, Form, Field } from "formik";
import React, { useState } from "react";
import RightBox from "./RightBox.js";
import LeftBox from "./LeftBox.js";
import "./Css/Feedback.css";
//import "index.css";

const Feedback = () => {
  return (
    <>
      {" "}
      <div className="wrapper">
        {" "}
        <BuyerSidebar />
        <LeftBox />
        <RightBox />
      </div>
    </>
  );
};

export default Feedback;
