const mongoose = require("mongoose");

const FeedbackSchema = new mongoose.Schema({
  _id: { type: String },
  firstName: { type: String },
  lastName: { type: String },
  sugeestion: { type: String },
});

const Feedback = mongoose.model("Feedback", FeedbackSchema);

module.exports = Feedback;
