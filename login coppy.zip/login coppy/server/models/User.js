const mongoose = require("mongoose");
const UserSchema = new mongoose.Schema({
  u_id: mongoose.Schema.Types.ObjectId,
  firstName: {
    type: String,
  },
  lastName: {
    type: String,
  },
  email: {
    type: String,
  },
  nic: { type: String },
  no: { type: String },
  street: { type: String },
  district: { type: String },
  zcode: { type: String },
  phoneno: { type: String },
  dlicence: { type: String },
  password: {
    type: String,
  },
  role: {
    type: String,
  },
});
const User = mongoose.model("User", UserSchema);
module.exports = User;
