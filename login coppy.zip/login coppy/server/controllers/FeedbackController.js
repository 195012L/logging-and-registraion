const Feedback = require("../models/Feedback");
const mongoose = require("mongoose");

exports.readController = async (req, res) => {
  await Feedback.find()
    .then((feedbacks) => {
      res.json(feedbacks);
    })
    .catch((err) => {
      console.log(err);
    });
};

exports.createController = async (req, res) => {
  const fname = req.body.fname;
  const lname = req.body.lname;
  const suggestion = req.body.suggestion;

  var newFeedback = new Feedback({
    _id: new mongoose.Types.ObjectId(),
    firstName: fname,
    lastName: lname,
    sugeestion: suggestion,
  });

  await newFeedback
    .save()
    .then(() => {
      res.json("FeedBack created");
    })
    .catch((err) => {
      console.log(err);
    });
};
