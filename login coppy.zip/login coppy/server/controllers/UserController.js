const User = require("../models/User");
const mongoose = require("mongoose");
module.exports = {
  addUser: async (req, res) => {
    console.log("hai");
    try {
      console.log("hai");
      console.log(req.body);
      var userData = new User({
        _id: new mongoose.Types.ObjectId(),
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        password: req.body.password,
        role: req.body.role,
        nic: req.body.nic,
        no: req.body.no,
        street: req.body.street,
        district: req.body.district,
        zcode: req.body.zcode,
        dlicence: req.body.dlicence,
      });
      userData.save((err, doc) => {
        if (!err) {
          res.json({
            success: true,
            message: "User registered successfully",
          });
        } else {
          res.json({
            success: false,
            message: "*** Student register failed ***",
          });
        }
      });
    } catch (err) {
      console.log(err);
    }
  },
  getUser: async (req, res) => {
    try {
      await User.find()
        .exec()
        .then((users) => {
          res.json({
            successs: true,
            message: "sucess",
            users: users,
          });
        });
    } catch (error) {
      res.json({
        successs: false,
        message: "faile",
      });
    }
  },

  updateUser: async (req, res) => {
    console.log("hai");
    try {
      console.log("hai");
      console.log(req.body);

      User.findByIdAndUpdate(
        req.body.id,
        {
          firstName: req.body.firstName,
          lastName: req.body.lastName,
          email: req.body.email,
          password: req.body.password,
          role: req.body.role,
          nic: req.body.nic,
          no: req.body.no,
          street: req.body.street,
          district: req.body.district,
          zcode: req.body.zcode,
          dlicence: req.body.dlicence,
        },
        (err, doc) => {
          if (!err) {
            res.json({
              success: true,
              message: "User Update successfully",
            });
          } else {
            res.json({
              success: false,
              message: err,
            });
          }
        }
      );
    } catch (err) {
      console.log(err);
    }
  },
};
